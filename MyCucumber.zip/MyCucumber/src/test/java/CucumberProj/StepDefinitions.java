package CucumberProj;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import pages.GoogleSearchPage;

public class StepDefinitions {
    WebDriver driver;
    GoogleSearchPage googleSearchPage;

    @Given("^i navigate to (.*?)$")
    public void i_navigate_to_https_www_google_com(String url) throws Exception {
        // Write code here that turns the phrase above into concrete actions
        System.out.println("navigate url:"+url);
        ////home/raj/IdeaProjects/MyCucumber/
        System.setProperty("webdriver.chrome.driver", "/home/raj/IdeaProjects/MyCucumber/src/test/resources/libs/chromedriver_linux64/chromedriver");
        driver = new ChromeDriver();
        driver.get(url);
        googleSearchPage = new GoogleSearchPage(driver);
    }

    @When("^i type search text in (.*?)")
    public void i_type_search_text_in_textbox(String searchText) throws Exception {
        // Write code here that turns the phrase above into concrete actions
        System.out.println("type text");
        googleSearchPage.searchAnyText(searchText);
    }

    @Then("^i see the search (.*?)$")
    public void i_seee_the_search_result(String result) throws Exception {
        // Write code here that turns the phrase above into concrete actions
        googleSearchPage.validateSearchResult(result);
        System.out.println("search text");
    }

    @Then("^i verify the page (.*?)$")
    public void i_verify_the_page_title(String expectedTitile) throws Exception {
        // Write code here that turns the phrase above into concrete actions
        googleSearchPage.validateTitle(expectedTitile);
    }
}
