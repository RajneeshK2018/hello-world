package Practise;

import java.util.ArrayList;
import java.util.List;

/*Given a number N, the task is to find the sum of digits of a number at even and odd places.
        Examples:

        Input: N = 54873
        Output:
        Sum odd = 16
        Sum even = 11

        Input: N = 457892
        Output:
        Sum odd = 20
        Sum even = 15*/

public class ReturnSumOfDigitsAtEvenAndOddPlaces_5 {
    List<Integer> odds = new ArrayList<>();
    List<Integer> evens = new ArrayList<>();

    public static void main(String[] args){
        int N = 457892;
        readEvenAndOdds(N);
    }

    private static void readEvenAndOdds(int n) {
        int newN = n;
        int i=1;
        int o=0;
        int e=0;

        do{
            if(i%2 == 0){
                e += newN%10;
            }else{
                o += newN%10;
            }
            newN = newN/10;
            i++;
        }while(newN > 0);

        System.out.println(o);
        System.out.println(e);
    }
}
