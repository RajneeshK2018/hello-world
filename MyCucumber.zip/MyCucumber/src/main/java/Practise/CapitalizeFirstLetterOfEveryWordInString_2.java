package Practise;

/*  Given a string, say sentence=" this is crazy and fun"
    and a list, say name=["is", "fun"].
    Now you need to capitalize on the first letter of
    every word in the given string which is not present in the list.*/

import java.util.ArrayList;

public class CapitalizeFirstLetterOfEveryWordInString_2 {
    public static void main(String[] args){
        String sentence=" this is crazy and fun";
        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add("is");
        arrayList.add("fun");

        //remove items that is available in List
        for (String alWord:arrayList) {
            if(sentence.contains(alWord)){
                String tempWord = (""+alWord.charAt(0)).toUpperCase()+alWord.substring(1,alWord.length());
                sentence = sentence.replace(alWord, tempWord);
            }
        }
        //Capitalise each word in String
        System.out.println("dede"+sentence);
    }
}
