package Practise;

import java.util.Arrays;

public class SimpleStreams {
    public static void main(String[] arg){
        int[] intArr = {1,2,3,4,5,6};
        int x = Arrays.stream(intArr).sum();
        System.out.println(x);

        Arrays.stream(intArr).count();
        int sum = Arrays.stream(intArr).reduce(0, Integer::sum);
        int newSum = Arrays.stream(intArr).reduce(0, (finalStr, eachEle) -> finalStr+eachEle);
        System.out.println(sum);
        System.out.println(newSum);
    }
}
