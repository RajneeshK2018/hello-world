package Practise;

import POJO.Employee;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class GenericsTest {
    public static void main(String[] args){
        List<Employee> employeeList = new ArrayList<>();
        employeeList.add(new Employee("f1","l1", 100.1, 100));
        employeeList.add(new Employee("f2","l2", 200.2, 200));
        employeeList.add(new Employee("f3","l3", 300.3, 300));

        Stream<Employee> filteredStream = employeeList.stream().filter(emp -> emp.getEmpId() > 100);
        //ssfilteredStream.collect();
    }
}
