package Practise;

import java.util.ArrayList;
import java.util.List;

public class PrintPrimeLessThanGivenNUmber_4 {
    public static void main(String[] s){
        getPrimeSum(20);
    }

    private static void getPrimeSum(int n) {
        List<Integer> prime = new ArrayList<>();
        for (int i=2; i<= n; i++){
            if(printPrime(i)){
                System.out.println(i);
                prime.add(i);
            }
        }
        normalSum(prime);
        normalSumGeneric(prime);
    }

    private static void normalSumGeneric(List<? extends Integer> prime) {
        int sum =0;
        for (Integer i:prime) {
            sum +=i;
        }

        System.out.println("normalSumGeneric:"+sum);
    }

    private static void normalSum(List<Integer> prime) {
        int sum =0;
        for (int i:prime) {
            sum +=i;
        }

        System.out.println("normalSum:"+sum);
    }

    private static boolean printPrime(int n) {
        boolean prime = true;

        for(int i=2; i < n; i++){
            if(n%i == 0){
                prime = false;
                break;
            }
        }
        return prime;
    }
}
