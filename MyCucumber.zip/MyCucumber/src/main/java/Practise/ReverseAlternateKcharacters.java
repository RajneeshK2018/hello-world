package Practise;

public class ReverseAlternateKcharacters {
/*    Given a string str and an integer k,
    the task is to reverse alternate k characters of the given string.
    If characters present are less than k, leave them as it is.

    Examples:
    Input: str = “geeksforgeeks”, k = 3
    Output: eegksfgroeeks

    Input: str = “abcde”, k = 2
    Output: bacde*/

    public static void main(String[] args){
        String str = "geeksforgeeks";
        String newStr = "";
        int k= 3;
        int i=1;

        do{
            //String sub =

        }while(newStr.length() > 0);
    }
}
