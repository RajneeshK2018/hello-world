package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.junit.Assert;

import java.util.concurrent.TimeUnit;

public class GoogleSearchPage {
    private WebDriver driver;
    private WebDriverWait wait;
    private String title;
    public GoogleSearchPage(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver, this);
        driver.manage().timeouts().pageLoadTimeout(3, TimeUnit.SECONDS);
        wait = new WebDriverWait(driver,2);
    }

    @FindBy(how = How.NAME, using = "q")
    WebElement inputBox;

    @FindBy(how = How.ID, using = "result-stats")
    WebElement searchResult;

    public void searchAnyText(String searchText){
        wait.until(ExpectedConditions.visibilityOf(inputBox));
        inputBox.click();
        inputBox.sendKeys(searchText);
        inputBox.submit();

    }

    public void validateTitle(String ExpectedTitle){
        Assert.assertEquals("Validating title",driver.getTitle(), ExpectedTitle);
    }

    public void validateSearchResult(String rajneesh) {
        Assert.assertEquals("Search result should display", searchResult.isDisplayed(), true);
    }
}
