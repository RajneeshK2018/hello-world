package POJO;

public class Employee {
    private String fName;
    private String lName;
    private double salary;
    private int empId;

    public Employee(String f1, String l1, double v, int i) {
        fName = f1;
        lName = l1;
        salary = v;
        empId = i;
    }

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getlNAme() {
        return lName;
    }

    public void setlNAme(String lNAme) {
        this.lName = lNAme;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(float salary) {
        this.salary = salary;
    }

    public int getEmpId() {
        return empId;
    }

    public void setEmpId(int empId) {
        this.empId = empId;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "fName='" + fName + '\'' +
                ", lName='" + lName + '\'' +
                ", salary=" + salary +
                ", empId=" + empId +
                '}';
    }
}
