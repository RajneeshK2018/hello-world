# RestAssuredFundamentals - Training Course code

This is all of the code used in my Udemy video series - REST Assured Fundamentals
