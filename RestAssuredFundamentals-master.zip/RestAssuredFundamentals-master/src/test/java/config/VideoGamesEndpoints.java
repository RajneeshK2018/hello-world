package config;

public interface VideoGamesEndpoints {

    String ALL_VIDEO_GAMES = "videogames";
    String SINGLE_VIDEO_GAME = "videogames/{videoGameId}";
}
