package ch_06_02_usage.begin;

import org.openqa.selenium.support.events.AbstractWebDriverEventListener;

public class ScreenshotterEventListener extends AbstractWebDriverEventListener{

    // TODO: add an after find By which gets a screenshot as file
    // and copies the file into a user.dir screenshots directory

}
