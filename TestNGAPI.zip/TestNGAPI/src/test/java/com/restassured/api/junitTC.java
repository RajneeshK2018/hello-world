package com.restassured.api;

import static org.junit.Assert.*;

import org.junit.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import static io.restassured.RestAssured.given;
import static io.restassured.RestAssured.when;
import io.restassured.internal.ResponseSpecificationImpl.HamcrestAssertionClosure;
import io.restassured.matcher.ResponseAwareMatcher;

import org.hamcrest.core.Is;
import org.hamcrest.Matchers;

import io.restassured.matcher.RestAssuredMatchers.*;
import org.hamcrest.Matchers.*;

public class junitTC {

	@Test
	public void test() {
		//given().get("/lotto").then().assertThat().body("data.id", equalTo(2));
		//given().get("https://reqres.in/api/users/2").then().assertThat().body("data.id", equalTo(2));
	
	}


	{
		// Using Rest-Assured class to setup a request
        RestAssured.baseURI = "https://reqres.in";
		// Getting the RequestSpecification of the request
		RequestSpecification httpRequest = RestAssured.given();
		
		
		        // Making GET request directly by RequestSpecification.get() method
		Response response = httpRequest.get("/api/users/2");
		
		
		        //Retrieving Body of response
		String body = response.getBody().asString();
		//Retrieving Status Code of response
		int status = response.getStatusCode();
		//Retrieving Status Line
		String statusLine = response.getStatusLine();
		
		
		//Printing the response
		System.out.println("Response Body is "+body);
		System.out.println("Status code is "+status);
		System.out.println("Status line is "+statusLine);
	}
}