package com.restassured.api;
import static org.junit.Assert.*;
import org.junit.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import junit.framework.Assert;

import static io.restassured.RestAssured.given;
import static io.restassured.RestAssured.when;
import io.restassured.internal.ResponseSpecificationImpl.HamcrestAssertionClosure;
import io.restassured.matcher.ResponseAwareMatcher;

import org.hamcrest.core.Is;
import org.hamcrest.Matchers;

import io.restassured.matcher.RestAssuredMatchers.*;
import org.hamcrest.Matchers.*;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import static org.hamcrest.Matchers.hasItems;
public class JUTest2 {

	@Test
	public void test1() {
		//Response response = given().
				Response response = RestAssured.get("https://reqres.in/api/users/2");
		System.out.println(response.asString());

		response.then().body("data.id", hasItems(2));
		
	}

}
