package com.restassured.api;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Api {

	public static void main(String[] args) {
		// Using Rest-Assured class to setup a request
        RestAssured.baseURI = "https://reqres.in";
		// Getting the RequestSpecification of the request
		RequestSpecification httpRequest = RestAssured.given();
		
		RequestSpecification reqSpec = new RequestSpecBuilder()
				.addHeader("Content-type", "applicatio/json")
				.build();
		
		RestAssured.requestSpecification = reqSpec;
		
		        // Making GET request directly by RequestSpecification.get() method
		Response response = httpRequest.get("/api/users/2");
		
		
		        //Retrieving Body of response
		String body = response.getBody().asString();
		//Retrieving Status Code of response
		int status = response.getStatusCode();
		//Retrieving Status Line
		String statusLine = response.getStatusLine();
		
		//Printing the response
		//System.out.println("Response Body is "+body);
		System.out.println("Status code is "+status);
		System.out.println("Status line is "+statusLine);
		
		int respId = response.path("data.id");
		System.out.println("Data extracted from response is "+respId);

	}

}
