package com.restassured.api;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import java.io.FileReader;
import java.util.HashMap;
import java.util.Map;

import static io.restassured.RestAssured.baseURI;

public class GET extends Api {

	public static void main(String[] args) {
		
		//http://code.haleby.se/2018/10/05/logging-to-disk-with-rest-assured/
		//http://restservicestesting.blogspot.com/2016/12/logging-in-rest-assured-response.html
		RestAssured rest = new RestAssured();
		Response response = rest.given()
				.log().ifValidationFails()
				.baseUri("https://reqres.in")
				.when()
				.when()
				.when()
				.header("page", 2)
				.header("id", 5)
			.when()
				.get("/api/users?page="+2+"&id="+5);
//			.then()
//				.log().all()
//				.statusCode(200);
		System.out.println("response.body() >>"+response);
		//System.out.println("response.body() >>"+response.);
	
	}

}
