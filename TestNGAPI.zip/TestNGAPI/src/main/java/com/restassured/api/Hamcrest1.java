package com.restassured.api;

import java.util.ArrayList;
import java.util.Arrays;
//import groovyjarjarantlr.collections.List;
import java.util.List;

import org.junit.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.anything;
import static org.hamcrest.Matchers.hasValue;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import static org.hamcrest.core.Every.everyItem;
import static org.hamcrest.core.IsEqual.equalTo;
import static org.hamcrest.Matchers.greaterThanOrEqualTo;

public class Hamcrest1 {

//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		List<Integer> list = Arrays.asList(5, 2, 4);
//		Integer i = new Integer(1);
//		
//		System.out.println((assertThat(5, greaterThanOrEqualTo(5))).);
//
//	}
	
	@Test
	public void Test1() {
		List<Long> actual = Arrays.asList(1L, 2L, 3L);
		List<Long> expected = Arrays.asList(1L, 2L, 3L);
		assertThat(actual, containsInAnyOrder(expected.toArray()));
	}
	
	@Test
	public void Test2() {
		Integer four = 5;
		assertThat(four, is(anything()));
	}
}
