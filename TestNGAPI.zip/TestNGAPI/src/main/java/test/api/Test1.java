package test.api;

import static org.hamcrest.CoreMatchers.equalTo;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.map.ObjectMapper;
import org.hamcrest.text.MatchesPattern;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.fasterxml.jackson.core.type.TypeReference;
import com.github.fge.jsonschema.SchemaVersion;
import com.github.fge.jsonschema.cfg.ValidationConfiguration;
import com.github.fge.jsonschema.main.JsonSchemaFactory;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath;

public class Test1 extends BaseTest {

	@BeforeClass
	public void mBeforeClass() {

		System.out.println("BEFORE_CLASS..");
		RequestSpecification reqSpec = new RequestSpecBuilder().addHeader("Content-Type", "application/json")
				.addHeader("Accept", "application/json").build();

	}

	@Test(enabled = true)
	public void ExtractASpecificGPath() {
		System.out.println("ExtractASpecificGPath......");
		RestAssured rest = new RestAssured();

		Response response = rest.given().when().get("https://jsonplaceholder.typicode.com/albums");
		Map<String, ?> xx= response.path("find {it.id == 5}");
		System.out.println("Response for a specific id==5: " + xx);
		System.out.println("finished..");
	}
	
	@Test(enabled = false)
	public void TestJsonSchema() {
		System.out.println("TestJsonSchema......");
		File json = new File("C:\\Users\\rajneesh.kumar\\TestNGAPI\\src\\main\\java\\ResponseFiles\\Resp1.json");
		//"C:\\Users\\rajneesh.kumar\\TestNGAPI\\src\\main\\java\\ResponseFiles\\Resp1.json"
		  ObjectMapper mapper = new ObjectMapper();
		  
		  System.out.println("TestList......"); RestAssured rest = new RestAssured();
		  
		  //Response response = rest.given() .when()
		  rest.get("https://jsonplaceholder.typicode.com/albums");
		  //.body(matchesJsonSchemaInClasspath("videoGameSchema.json"));
		  
		  System.out.println("Full response body in string format: ");
		 

	}

	@Test(enabled = false)
	public void DeserializeArrayList() {
		System.out.println("TestListArray2ArrayCompare......");
		ObjectMapper mapper = new ObjectMapper();

		try {
			File json = new File("C:\\Users\\rajneesh.kumar\\TestNGAPI\\src\\main\\java\\ResponseFiles\\Resp1.json");
			EmpPOJO[] emppojo = mapper.readValue(json, EmpPOJO[].class);
			System.out.println("Emp Array created..");
			System.out.println(emppojo.length);
			System.out.println(emppojo[0]);
			System.out.println(emppojo[1]);

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Test(enabled = false)
	public void TestListArray2ArrayCompare() {
		System.out.println("TestListArray2ArrayCompare......");
		ObjectMapper mapper = new ObjectMapper();

		try {
			File json = new File("C:\\Users\\rajneesh.kumar\\TestNGAPI\\src\\main\\java\\ResponseFiles\\Resp2.json");
			EmpPOJO emppojo = mapper.readValue(json, EmpPOJO.class);
			System.out.println("Java object created from JSON String :");
			System.out.println(emppojo);

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Test(enabled = false)
	public void TestList() {
		System.out.println("TestList......");
		RestAssured rest = new RestAssured();

		Response response = rest.given().when().get("https://jsonplaceholder.typicode.com/albums");

		System.out.println("Full response body in string format: " + response.asString());
		EmpPOJO[] arrResp = response.as(EmpPOJO[].class);
		System.out.println("Size: " + arrResp.length);
		System.out.println("finished..");
	}

	@Test(enabled = false)
	public void TestExtractId() {
		System.out.println("TestExtractId......");
		RestAssured rest = new RestAssured();

		Response response = rest.given().header("page", 2).header("id", 5).when()
				.get("https://reqres.in/api/users?page=" + 2 + "&id=" + 5);

		// First get the JsonPath object instance from the Response interface
		JsonPath jsonPathEvaluator = response.jsonPath();
		System.out.println("full response: " + response.asString());
		System.out.println("data.id: " + jsonPathEvaluator.get("data.id"));
		System.out.println("data.id: " + jsonPathEvaluator.get("data.last_name"));

	}

	@Test(enabled = false)
	public void Test1() {
		System.out.println("Test1......");
		RestAssured rest = new RestAssured();

		Response response = rest.given().header("page", 2).header("id", 5).when()
				.get("https://reqres.in/api/users?page=" + 2 + "&id=" + 5);

		System.out.println("response body in string format: " + response.asString());
		Assert.assertEquals(2, 2);
	}

}
