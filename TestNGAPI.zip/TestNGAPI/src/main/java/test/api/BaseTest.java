package test.api;
import org.testng.annotations.*;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
public class BaseTest {
    //static RequestSpecification req;
    @BeforeSuite
    public void mBeforeSuite(){
        System.out.println("BEFORE_SUITE");


    }

    @BeforeTest
    public void setup(){
        System.out.println("BEFORE_TEST");
    }


    @BeforeMethod
    public void mBeforeMethod(){
        System.out.println("BEFORE_METHOD");
    }

    @AfterClass
    public void mAfterClass(){
        System.out.println("AFTER_CLASS");
    }

    @AfterMethod
    public void mAfterMethod(){
        System.out.println("AFTER_METHOD");
    }

    @AfterSuite
    public void mAfterSuite(){
        System.out.println("AFTER_SUITE");
    }

    @AfterTest
    public void mAfterTest(){
        System.out.println("AFTER_TEST");
    }
}
