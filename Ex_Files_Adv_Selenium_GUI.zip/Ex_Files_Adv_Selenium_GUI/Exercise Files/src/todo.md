
- what you should know
   - how to install WebDriver, the test code uses ChromeDriver throughout.
   

- 01-03-RefactoringToAbstractions
    - coded
    - scripted
   
_02_04_driver_Abstractions
    - coded
    - scripted
    
- _02_05_technology_abstractions
    - coded
    - scripted    
       
- _02_06_storage_refactoring
    - coded
    - scripted       
    
- _02_07_element_abstractions
   - coded
   - scripted
 
- _03_01_page_objects
   - coded
   - scripted