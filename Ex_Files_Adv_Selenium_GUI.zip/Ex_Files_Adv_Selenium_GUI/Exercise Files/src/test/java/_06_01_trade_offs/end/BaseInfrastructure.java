package _06_01_trade_offs.end;

public class BaseInfrastructure {

    public String getMainPageUrl(){
        return
            "https://eviltester.github.io/simpletodolist/todolists.html";
    }

}
