package _06_01_trade_offs.begin;


public class TradeOffsTest {
}
