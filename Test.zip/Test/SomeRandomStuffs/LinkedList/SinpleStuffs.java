package LinkedList;

import java.util.LinkedList;

public class SinpleStuffs {
    public static  void main(String[] args){
        System.out.println("");
        LinkedList<Integer> llst = new LinkedList();
        llst.add(1);
        llst.add(2);
        llst.add(3);
        llst.add(4);
        llst.add(5);

    int size = llst.size();
        System.out.println();
    }
}
