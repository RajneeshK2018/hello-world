package GFG;

import java.util.Arrays;
import java.util.Comparator;

public class SortJavaStringAsPerWordSize {
    public static  void main(String[] args){
        String s = "going is rohit to pune za lo";
        StringBuilder sb = new StringBuilder(s);
        String[] arrS = s.split(" ");
        System.out.println(arrS);
        //Arrays.sort(arrS);
       Arrays.sort(arrS, new Comparator<String>() {
                    @Override
                    public int compare(String o1, String o2) {
                        int retType = -1;
                        if (o1.length() == o2.length()) {
                            return -1;
                        }else if (o1.length() > o2.length()){
                            return 1;
                        }
                        return retType;
                    }
                }
        );
        System.out.println(arrS);
        System.out.println("");
    }
}
