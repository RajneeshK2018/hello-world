package GFG;

import java.util.*;

public class FirstAndLastIndex {
    public static  void main(String[] args){
        System.out.println("");
        Integer[] x = {1,2,2,4,5,1,0};
        int n = 2;

        Integer[] newArray = Arrays.copyOfRange(x, 2, x.length - 2);
        List<Integer> lst = Arrays.asList(x);
        System.out.println(lst.indexOf(n));


        System.out.println(lst.contains(8));

        Collections.reverse(lst);
        System.out.println(lst.size() - lst.indexOf(n)-1);
        ArrayList<Integer> arList = new ArrayList(Arrays.asList(x));
        arList.removeIf(m -> m == n);

        System.out.println(arList);
    }
}
