package GFG;

import java.util.Arrays;

public class SubarrayWithGivenSum_ArraySort {
    public static void main (String[] args) {
        //code

        int[] A = {1,2,3,4,5,6,7,8,9,10};
        int S = 9;
        Arrays.sort(A);
        int sum = 0;
        for (int i=0; i < A.length; i++){
            sum = sum + A[i];
            /*if(sum == A){
                printArray(i);
            }*/

        }
    }

    public static void printArray(int i, int j, int[] A){
        String s = "";
        for (int k = i; k <= j; k++){
            s = s+A[k]+", ";
        }
        System.out.println(s);
    }
}
