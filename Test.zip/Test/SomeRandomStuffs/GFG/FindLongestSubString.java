package GFG;

public class FindLongestSubString {
    public static  void main(String[] args){
        String s = "abcaabcd";


       for (int i=0; i< s.length(); i++){
        String s1 = s.substring(i);
        for(int j = i+1; j < s.length() ; j++){
            String tempS = s.substring(i);
        }
       }
    }
}
