package GFG;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class LongestPelindrome {
    public static  void main(String[] args){
        String s = "XPABCBAPMNPABCBAPNMD";
        System.out.println("");
        char[] chrS = s.toCharArray();
        List<Integer> lst = new ArrayList<>();
        List<Integer> pelLength = new ArrayList<>();

        for (int i=1; i< chrS.length-1; i++){
            if(chrS[i-1] == chrS[i+1]){
                lst.add(i);
            }
        }

        int mxIndx = -1;
        int mxsize = -1;

        for(int i=0; i < lst.size(); i++){
            int startIndx = lst.get(i);
            int j = 0;
            char rght;
            char lft;
            try {
                do {
                    j++;
                    rght =chrS[startIndx -j];
                    lft =chrS[startIndx +j];

                }while(rght == lft);
            } catch (Exception e) {
                e.printStackTrace();
            }

            if(mxIndx == -1){
                mxIndx = startIndx;
                mxsize = j;
            }else if(j > mxsize){
                mxIndx = startIndx;
                mxsize = j;
            }
        }

        System.out.println(mxIndx+mxsize);
        String pel=""+chrS[mxIndx];
        for (int i = 1; i <=mxsize; i++ ){
            pel = chrS[mxsize-i]+pel+chrS[mxsize+i];
        }
        System.out.println(pel);
    }
}
