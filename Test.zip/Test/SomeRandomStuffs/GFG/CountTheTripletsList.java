package GFG;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class CountTheTripletsList {
    public static  void main(String[] args){
        System.out.println("CountTheTriplets");
        Integer[]  arr = {1,2,3,4,5,9};
        List<Integer> lst = Arrays.asList(arr);
        String indUsed = "";
        HashMap<Integer, String> usedMap = new HashMap<>();

        for (int i = 0; i < lst.size(); i++){
            int tempInt = lst.get(i);
            for (int j = 0; j < lst.size(); j++){
                if(i != j){
                    int t1 = lst.get(j);
                    if (lst.contains(tempInt - t1)){
                        System.out.println(tempInt+t1+(tempInt - t1));
                        int tempIndx = lst.indexOf((tempInt - t1));
                        String indexes = "";
                        if(j > tempIndx){
                            indexes = ""+tempIndx+j;
                        }else{
                            indexes = ""+j+tempIndx;
                        }
                        usedMap.put(tempInt,indexes);
                    }
                }
            }

        }


        System.out.println("Finishing CountTheTriplets");
    }

    public static boolean elementExistsInArray(Integer[] arr, Integer targetValue) {
        return Arrays.asList(arr).contains(targetValue);
    }
}
