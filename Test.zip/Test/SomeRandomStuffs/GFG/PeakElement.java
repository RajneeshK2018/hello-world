package GFG;

public class PeakElement {
    public static  void main(String[] args){
        System.out.println("");

        int[] arr = {2,10,3,0};
        for (int i=1; i < arr.length-1; i++){
            int current = arr[i];
            int prev = arr[i-1];
            int nxt = arr[i+1];

            if((current >= prev) && (current >= nxt )){
                System.out.println(i);
            }
        }
    }
}
