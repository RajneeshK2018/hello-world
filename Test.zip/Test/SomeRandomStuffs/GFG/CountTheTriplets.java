package GFG;

import java.util.Arrays;

public class CountTheTriplets {
    public static  void main(String[] args){
        System.out.println("CountTheTriplets");
        Integer[]  arr = {1,2,3,4,5, 9};

        for (int i=0; i < arr.length ; i++){
            Integer tempInt = arr[i];
            for (int j=0; j < arr.length; j++){
                if(i!=j) {
                    int int1 = arr[j];
                    if (int1 < tempInt) {
                        if (elementExistsInArray(arr, (tempInt - int1))) {
                            System.out.println(tempInt + "= " + int1 + "+" + (tempInt - int1));
                        }
                    }
                }
            }
        }
    }

    public static boolean elementExistsInArray(Integer[] arr, Integer targetValue) {
        return Arrays.asList(arr).contains(targetValue);
    }
}
