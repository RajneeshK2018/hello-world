package GFG;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class LongestCommonSubstring {
    public static ArrayList<String> lstComonSub = new ArrayList<>();
    public static  void main(String[] args){
        String s1 = "abcde1111abc";
        String s2 = "23455abcde9";

        String smallerStr;
        String longString;
        if(s1.length() > s2.length()){
            smallerStr = s2;
            longString = s1;
        }else {
            smallerStr = s1;
            longString = s2;
        }

        for(int i=0; i<smallerStr.length()-2;i++){
            String subS = smallerStr.substring(i, i+2);
            //System.out.println(subS);
            if(longString.indexOf(subS) > 0){
                getSubstring(smallerStr,longString, i, longString.indexOf(subS));
            }
        }

        Collections.sort(lstComonSub, new Comparator<String>() {
            @Override
            public int compare(String o1, String o2) {
                return o2.length()-o1.length();
            }
        });
        System.out.println(lstComonSub.get(0));
    }

    private static void getSubstring(String smallerStr, String longString, int smallStart, int start) {
        String commonStrng = "";
        int i=0;
        do{
            i++;
            String s1 = smallerStr.substring(smallStart, smallStart+i);
            String s2 = longString.substring(start, start+i);
            if(s1.equals(s2)) {
                commonStrng =  s1;
            }else{
                lstComonSub.add(commonStrng);
                break;
            }
        }while(i <(smallerStr.length() - smallStart));
    }
}
