package GFG;

public class SubarrayWithGivenSum {
    public static void main (String[] args) {
        //code

        int[] A = {1,2,3,4,5,6,7,8,9,10};
        int S = 9;
        for (int i=0; i < A.length; i++){
            int sum = A[i];
            for(int j=i; j< A.length; j++){
                if(i != j){
                sum = sum + A[j];}
                if(sum == S){
                    printArray(i,j, A);
                    break;
                }else if(sum > S){
                    break;
                }
            }
        }
    }

    public static void printArray(int i, int j, int[] A){
        String s = "";
        for (int k = i; k <= j; k++){
            s = s+A[k]+", ";
        }
        System.out.println(s);
    }
}
