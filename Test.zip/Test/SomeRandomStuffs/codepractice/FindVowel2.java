package codepractice;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FindVowel2 {
    public static void main(String[] arg){
        String[] arrVowel = {"a", "e", "i", "o", "u"};
        String str = "iretg";
        System.out.println(hasVowels(arrVowel, str));

    }

    private static boolean hasVowels(String[] arrVowel, String str) {
        boolean found = false;
        for (int i = 0; i < arrVowel.length; i++){
            if(str.contains(arrVowel[i])){
                return true;
            }
        }
        return false;
    }

}
