package codepractice;

public class LargestNumberLessThanGivenNumber {
    public static  void main(String[] args){
        int n = 555;
        int digitToAvoid = 5;
        String strdigitToAvoid = digitToAvoid+"";
        int prevNumber = n;
        while(prevNumber >1){
            prevNumber = prevNumber -1;
            String strprevNumber;
            strprevNumber = prevNumber + "";
            if (!strprevNumber.contains(strdigitToAvoid)){
                System.out.println(""+strprevNumber);
                break;
            }

        }

    }
}
