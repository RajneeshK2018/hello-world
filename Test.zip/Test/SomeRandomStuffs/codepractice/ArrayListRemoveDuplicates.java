package codepractice;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

public class ArrayListRemoveDuplicates {
    public static  void main(String[] args){
        ArrayList<Integer> al = new ArrayList<>();
        al.add(1);
        al.add(11);
        al.add(111);
        al.add(111);
        al.add(10);
        al.add(10);
        al.add(10);
        al.add(10);

        //Set<Integer> set = new HashSet<>(al);
        Set<Integer> set = new LinkedHashSet<>(al);
        al.clear();
        al.addAll(set);
        System.out.println("");
    }
}
