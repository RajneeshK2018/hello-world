package codepractice;

public class Null {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Object n;
		n = null;
		try {
		if (n.equals(null)) {
			System.out.println("null");
		}
		}catch(Exception e) {
			System.out.println("null is neing used");
		}
	}

}
