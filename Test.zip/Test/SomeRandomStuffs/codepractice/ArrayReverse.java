package codepractice;

public class ArrayReverse {
    public static  void main(String[] args){
        System.out.println("");
        int[] arr =null;
        int temp;
        int l;

        arr = new int[]{1, 2, 3, 4};

        int[] arr2 = new int[arr.length];
        l = arr.length;
        for (int i = 0; i < arr.length; i++){
            temp = arr[l-1 -i];
            arr2[i] = temp;
        }

        System.out.println("end");
    }
}
