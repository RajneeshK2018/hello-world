package codepractice;

public class Transpose {
    public static  void main(String[] args){

        int[][] foo = new int[][] {
                new int[] { 1, 2, 3, 4 },
                new int[] { 11, 22, 33, 44},
        };
        transpose(foo);
        System.out.println("");
    }

    public static int[][] transpose(int arr[][]){
        int m = arr.length;
        int n = arr[0].length;
        int ret[][] = new int[n][m];

        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                ret[j][i] = arr[i][j];
            }
        }

        return ret;
    }
}
