package codepractice;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class StringReverse1 {
    public static  void main(String[] args){
        String s = "I am living in pune.";
        String s1 = "";

        char[] charArray = s.toCharArray();
        List<String> x = Arrays.asList();


        System.out.println("Reverse: "+ new StringBuilder(s).reverse());
        for (int i = s.length()-1; i>=0; i--){
            s1 += s.charAt(i);
        }
        System.out.println("ppppppp: "+s1);
    }
}
