package codepractice;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RexexPattern {
    public static void main(String args[]){
        final String input = "i am in pune and will be in pune.";
        final String regex = "[a-zA-Z]";
        final Matcher m = Pattern.compile(regex).matcher(input);

        final List<String> matches = new ArrayList<>();
        while (m.find()) {
            matches.add(m.group(0));
        }

        System.out.println(matches);
    }
}
