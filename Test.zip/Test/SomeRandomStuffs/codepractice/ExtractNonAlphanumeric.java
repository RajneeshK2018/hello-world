package codepractice;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ExtractNonAlphanumeric {
    public static void main(String args[]){
        final String input = "abc12ter567@gdgdgd55uu?yrtuu0.";
        final String regex = "[^a-zA-Z0-9]+";
        final Matcher m = Pattern.compile(regex).matcher(input);

        final List<String> matches = new ArrayList<>();
        while (m.find()) {
            matches.add(m.group(0));
        }

        System.out.println(matches);
    }
}
