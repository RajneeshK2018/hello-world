package codepractice;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class CollectionsCollectionDemo {

	public static void main(String[] args) {
		Collection<Integer> collCollection1;
		Collection<Integer> collCollection2;
	
		collCollection1 = new ArrayList<Integer>();
		//collCollection2 = new 
		
	}
}
