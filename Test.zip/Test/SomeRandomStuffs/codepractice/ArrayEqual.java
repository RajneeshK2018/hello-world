package codepractice;

import java.util.Arrays;

public class ArrayEqual {
    public static  void main(String[] args){
        String[] arr1 = new String[]{"1", "11","111","2","22 "};
        String[] arr2 = new String[]{"1", "11","111","2","22"};

        if ( Arrays.equals(arr1, arr2)){
            System.out.println("Equal");
        }else
            System.out.println("Un equal");
    }
}
