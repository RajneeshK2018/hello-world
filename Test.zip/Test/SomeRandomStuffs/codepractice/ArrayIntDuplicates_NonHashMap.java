package codepractice;

import java.util.Arrays;
import java.util.HashMap;

public class ArrayIntDuplicates_NonHashMap {
    public static  void main(String[] args) {
        int[] arr2 = new int[]{1, 2, 3,1, 5, 5, 2};

        String s= Arrays.toString(arr2);
        String sNoComma = s.replace(",","");
        for (int i=0; i < arr2. length; i++){
            String eachS = arr2[i]+"";
            String newS = s.replaceAll("\\b"+eachS+"\\b", "");
            String newSwithoutComma = newS.replace(",","");

            if((sNoComma.length() - newSwithoutComma.length()) == eachS.length()){
                System.out.println(eachS);
            }
        }
        HashMap<String, Integer> hm = new HashMap<>();
    }
}
