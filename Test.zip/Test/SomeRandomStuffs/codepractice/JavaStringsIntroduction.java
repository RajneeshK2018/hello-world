package codepractice;

public class JavaStringsIntroduction {

	public static void main(String[] args) {
		String x = "aa";
		String y = "aad";
		JavaStringsIntroduction1(x,y);

	}
	
	public static void JavaStringsIntroduction1(String s1, String s2) {
		int t = s1.compareTo(s2);
		 if (t > 0) {
			 System.out.println(s1+" is greater than "+s2);
		 }else if(t <0) {
			 System.out.println(s2+" is greater than "+s1);
		 }else {
			 System.out.println(s2+" = "+s1);
		 }
		
	}

}
