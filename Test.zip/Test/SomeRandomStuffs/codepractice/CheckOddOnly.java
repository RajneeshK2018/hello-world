package codepractice;

import java.util.ArrayList;
import java.util.List;

public class CheckOddOnly {
    public static void main(String[] args) {
        List<Integer> lst = new ArrayList<>();
        lst.add(1);
        lst.add(23);
        lst.add(3);
        lst.add(5);

        for (int i = 0; i < lst.size(); i++) {
            if(lst.get(i)%2 == 0){
                System.out.println("NO Prime");
                break;
            }
        }
    }
}