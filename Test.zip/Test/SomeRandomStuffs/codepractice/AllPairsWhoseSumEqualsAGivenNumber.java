package codepractice;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class AllPairsWhoseSumEqualsAGivenNumber {
    public static  void main(String[] args) {
        int givenNumber = 10;
        int[] arr2 = new int[]{1, 2, 3, 4, 5, 6, 7, 8, 2, 7, 3, 9};
        HashMap<Integer, Integer> hm = new HashMap<>();

        for (int i = 0; i < arr2.length; i++) {
            for (int j = i + 1; j < arr2.length; j++) {
                if (arr2[i] + arr2[j] == givenNumber) {
                    System.out.println(+arr2[i] + " " + arr2[j]);
                    if(!hm.containsKey(arr2[i]) && !hm.containsKey(givenNumber - arr2[i])){
                        hm.put(arr2[i],givenNumber - arr2[i] );
                    }
                } else {
                    continue;
                }
            }
        }
        System.out.println("hm>>"+hm);
    }
}
