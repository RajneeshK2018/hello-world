package codepractice;

public class Febonacii {
    public static  void main(String[] args){

    }
}
