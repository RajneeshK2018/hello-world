package codepractice;

import java.util.ArrayList;
import java.util.List;

public class TEMPLATE {
    public static  void main(String[] args) {
    }
}
