package codepractice;

public class SubArrayWithSumEqualToGivenNumber {
    public static  void main(String[] args){
        int givenNumber = 3;
        int[] arr2 = new int[]{1,2,1,1,1,0,3};
        System.out.println("");

        for (int i = 0; i < arr2.length ; i++){
            int sum = 0;
            for (int j = i; j<arr2.length; j++){
                int start = i;
                sum = sum + arr2[j];
                if (sum == givenNumber){
                    printNumber(start, j,arr2);
                }else if(sum > givenNumber){
                    break;
                }
            }

        }
    }

    private static void printNumber(int s, int j, int[] arr2) {
        for (int i=s;i<=j;i++ ){
            System.out.print(arr2[i]);
        }
        System.out.println("");
    }
}
