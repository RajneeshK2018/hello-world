package codepractice;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ArrayDuplicates {
    public static  void main(String[] args) {
        int[] arr2 = new int[]{1, 4, 4, 1, 3, 4};
        HashMap<Integer, Integer> hm = new HashMap<>();
        for (int i =0; i< arr2.length; i++){
            int temp = arr2[i];
            if(hm.containsKey(temp)){
                hm.replace(temp,hm.get(temp)+1);
            }else{
                hm.put(temp, 1);
            }
        }


        for(Map.Entry<Integer, Integer> e : hm.entrySet()){
            if(e.getValue() ==1){
                System.out.println(e.getKey());
            }
        }
    }
}
