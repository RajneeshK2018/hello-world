package codepractice;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class ListCollectionDemo {

	public static void main(String[] args) {
		List<String> l = new ArrayList<String>();
		Set<String> s = new HashSet<String>();
		
		for(int i=1; i<=5; i++) {
			l.add("L"+i);
		}

		l.add("L-new");
		l.add(null);
		
		for(int i=1; i<l.size() ; i++) {
			System.out.println("L"+i+": "+l.get(i));
		}
		System.out.println("List size: "+l.size());

		
		Iterator<String> x = l.iterator();
	
		while(x.hasNext()) {
			System.out.println("Iterator List size: "+x.next());
		}
		
		
	}
}
