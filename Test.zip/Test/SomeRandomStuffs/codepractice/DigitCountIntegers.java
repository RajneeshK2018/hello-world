package codepractice;

import java.util.Arrays;

public class DigitCountIntegers {
    public static void main(String[] args){
        int[] intArr = {1,1,2,3,4,4,5,6};
        getSortedArray(intArr, "assending");
        
        int x = 12345;
        getDigitCount(x);
    }

    private static void getSortedArray(int[] intArr, String assending) {
       // Arrays.sort(intArr, );
    }

    private static void getDigitCount(int x) {
        int count = 0;
        do{
            x = x/10;
            count++;
        }while(x>0);
        System.out.println(count);
    }
}
