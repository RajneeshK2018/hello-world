package codepractice;

import java.util.Arrays;
import java.util.List;

public class LeftRotation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] x = {1,2,3,4,5};
		int start = 2;
		
		/*
		 * int[] y = new int[x.length];
		 * 
		 * for (int i=start; i< x.length;i++) { y[i-start] = x[i]; }
		 * 
		 * for (int i=x.length - start; i < x.length; i++ ) {
		 * 
		 * }
		 */
		
//		String s1 = Arrays.toString(x);
//		System.out.println(s1);
//		StringBuffer sb = new StringBuffer(s1);
//		String a = sb.substring(0, start-1);
//		String b = sb.substring(start, x.length);
//		String s2 = b+a;
//		System.out.println(s2);
		
		List<int[]> lst = Arrays.asList(x);
		List<int[]> l1 = lst.subList(1, start-1);
		List<int[]> l2 = lst.subList(start, lst.size()-1);

		System.out.println("de");
	}

}
