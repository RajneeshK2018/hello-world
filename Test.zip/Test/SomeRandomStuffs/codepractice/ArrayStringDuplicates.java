package codepractice;

import java.util.HashMap;
import java.util.Map;

public class ArrayStringDuplicates {
    public static  void main(String[] args) {


        String[] arr2 = new String[]{"abc", "bb", "c", "abc", "cc"};
        HashMap<String, Integer> hm = new HashMap<>();
        for (int i =0; i< arr2.length; i++){
            String temp = arr2[i];
            if(hm.containsKey(temp)){
                hm.replace(temp,hm.get(temp)+1);
            }else{
                hm.put(temp, 1);
            }
        }

        for(Map.Entry<String, Integer> e : hm.entrySet()){
            if(e.getValue() ==1){
                System.out.println(e.getKey());
            }
        }
    }
}
