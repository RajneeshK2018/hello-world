package codepractice;

public class DuplicateChars {
    public static  void main(String[] args){
        System.out.println("");
        String s = "Better butterrr";
        String done = "";

        //----------
        for (int i = 0; i < s.length(); i++){
            char s1 = s.charAt(i);
            String s2 = s.replace(s1+"", "");
            if((s.length() - s2.length() >= 1) && (!done.contains(s1+""))) {
                done = done+s1;
                System.out.println(s1 + ":" + (s.length() - s2.length()));
            }
        }

    }
}
