package codepractice;

import java.util.Arrays;
import java.util.HashMap;

public class ArrayGenericDuplicates_NonHashMap {
    public static  void main(String[] args) {
        double[] arr2 = new double[]{1.3, 2, 3, 1, 5, 5, 2};

        String s= Arrays.toString(arr2);
        String sNoComma = s.replace(",","");
        for (int i=0; i < arr2. length; i++){
            String eachS = arr2[i]+"";
            String newS = s.replaceAll("\\b"+eachS+"\\b", "");
            String newSwithoutComma = newS.replace(",","");

            if((sNoComma.length() - newSwithoutComma.length()) == eachS.length()){
                System.out.println(eachS);
            }
        }
    }

    public void getUnique(){

    }
}
