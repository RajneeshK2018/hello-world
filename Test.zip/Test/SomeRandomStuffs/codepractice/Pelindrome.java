package codepractice;

public class Pelindrome {
    public static  void main(String[] args) {
        String s = "abcdba";
        System.out.println(isPendrome(s));
    }

    private static boolean isPendrome(String s) {
        String revStr = stringReverse(s);
        if(s.equals(revStr)){
            return true;
        }
        return false;
    }

    private static String stringReverse(String s) {
    StringBuilder sb = new StringBuilder(s);
    return sb.reverse().toString();
    }
}
