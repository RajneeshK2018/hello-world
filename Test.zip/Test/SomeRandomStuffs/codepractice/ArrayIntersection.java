package codepractice;

import java.util.ArrayList;
import java.util.List;

public class ArrayIntersection {
    public static  void main(String[] args){
        System.out.println("");
        int[] x;
        int[] y;
        x = new int[]{1, 2, 3, 4, 5,8};
        y = new int[]{8,2,22,33,4,55};

        List<Integer> lst = new ArrayList<>();

        int len = x.length < y.length ? x.length:y.length;

        for (int i = 0; i < x.length && i <y.length; i++){
        if(elementExistInArray(x, y[i])){
            lst.add(y[i]);
        }
        }

        System.out.println(lst);
    }

    private static boolean elementExistInArray(int[] a, int b){
        for (int i = 0; i < a.length; i++){
            if (a[i] == b){
                return true;
            }
        }
        return false;
    }
}
