package codepractice;

public class RotationalString {
    public static  void main(String[] args){
        String s1 = "Iaminpune";
        String s2 = "neIaminpu";
        String subS = "";
        for (int i=0; i < s1.length(); i++){
            subS = s1.substring(0,i);
            if (!s2.contains(subS)){
                verifySecondPArt(s1, s2, i);
                break;
            }
        }
        System.out.println("");
    }

    private static void verifySecondPArt(String s1, String s2, int i) {
        String subStr = s1.substring(i, s1.length());
        if (s2.contains(subStr)){
            System.out.println("rotation");
        }else{
            System.out.println("NOn rotation");
        }
    }
}
