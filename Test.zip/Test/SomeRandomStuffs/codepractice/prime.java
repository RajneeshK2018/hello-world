package codepractice;

public class prime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int x = 0;
		x = 8;
		
		boolean prime = true;
		
		for (int i=2; i < x; i++) {
			if(x%i == 0) {
				
				prime = false;
				break;
			}
		}
		
		if(prime) {
			System.out.println("Prime");
		}else {
			System.out.println("non Prime");
		}
	}

}
