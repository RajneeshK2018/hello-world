package codepractice;

public class FirstNonRepititaveChar {
    public static  void main(String[] args){
        String s = "rajneeshra";
        char sunS;
        for (int i=0; i<=s.length();i++){

            char subS = s.charAt(i);
            if(conrOccurance(s,subS) == 1){
                System.out.println(subS);
                break;


            }
        }
    }

    public static int conrOccurance(String s, char l){
        String s2 = l+"";
        return s.length() - s.replace(s2,"").length();
    }
}
