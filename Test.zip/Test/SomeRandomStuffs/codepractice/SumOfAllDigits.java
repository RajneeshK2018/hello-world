package codepractice;

public class SumOfAllDigits {
    public static  void main(String[] args){
        int x = 1239;
        int s = 0;
        int x1 =x;

        while(x1 % 10 != 0){
            s = s+x1%10;
            x1 = x1/10;
        }
        System.out.println(""+s);
    }
}
