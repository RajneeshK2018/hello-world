package codepractice;

import java.util.HashMap;

public class CharOccuranceCount {
    public static  void main(String[] args){
        String s = "aaabbcdpoiud";
        HashMap<Character, Integer> hm = new HashMap<>();
        char sunS;
        for (int i=0; i<s.length();i++){

            char subS = s.charAt(i);
            hm.put(subS,conrOccurance(s, subS) );
        }

        System.out.println(hm);
    }

    public static int conrOccurance(String s, char l){
        String s2 = l+"";
        return s.length() - s.replace(s2,"").length();
    }
}
