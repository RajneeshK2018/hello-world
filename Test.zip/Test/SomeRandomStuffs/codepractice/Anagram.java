package codepractice;

import java.util.*;

public class Anagram {
    public static void main(String args[]){
        String s1 = "ACTUACTBU";
        String s2 = "TAUC";

        //System.out.println(crateOccurance(s1));

        System.out.println(s1.replaceAll("A", "**"));

        System.out.println(s1.replace("A","++"));
        System.out.println(s1.substring(3,4));
        System.out.println(s1.substring(4));

        System.out.println(s1.codePointAt(3));
/*
        Arrays.


        System.out.println(s1);*/


    }

    private static void hashMapComparision(String s1, String s2) {
        HashMap<String, Integer> x1 = crateOccurance(s1);
        HashMap<String, Integer> x2 = crateOccurance(s2);

        if(x1.equals(x2)){
            System.out.println("codepractice.Anagram 2");
        }else{
            System.out.println("Not codepractice.Anagram 2");
        }

        removeHM(x1);
    }

    private static void removeHM(HashMap<String, Integer> hm) {
        hm.remove("B");

        System.out.println("After removal: "+hm);
    }

    private static HashMap<String, Integer>  crateOccurance(String s1) {
        String tempS = s1;
        String tempS2 = "";
        HashMap<String, Integer> hm = new HashMap<>();

        do{
            tempS2 = tempS.replace(tempS.charAt(0)+"","");
            hm.put(tempS.charAt(0)+"", tempS.length() - tempS2.length());
            tempS = tempS2;
        }while(tempS.length() > 0);
        System.out.println(hm);
        return hm;
    }
}
