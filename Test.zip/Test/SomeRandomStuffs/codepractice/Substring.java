package codepractice;

public class Substring {
    public static void main(String rags[]){
     System.out.println("Start,,");
     String s = "I am in pune";
     int start = 1;
     int end = 6;

        subStr(s, start, end);
    }

    public static void subStr(String str, int s, int e){
        System.out.println(str.substring(s,e));
    }
}
