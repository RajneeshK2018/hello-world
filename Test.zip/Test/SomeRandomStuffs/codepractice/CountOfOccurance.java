package codepractice;

public class CountOfOccurance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String x = "am";
		String y = "i am in am in wswseded ";
		count(y,x);
		
		
	}
	
	public static void count(String a, String b) {
		String s1 = a.replaceAll(b, "");
		System.out.println(s1);
		System.out.println((a.length() - s1.length())/b.length());
	}

}
