package codepractice;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ArraySort {
	public static void main(String args[]) {
		Integer[] x = new Integer[3];

			x[0] = 4;
			x[1] = 0;
			x[2] = 1;
		
			Arrays.sort(x);
		
			//List<Integer> lst = Arrays.asList(x);
		
			
		  List<Integer> intList1 = new ArrayList<Integer>(x.length); 
		  
		  for (int i = 0; i< x.length; i++) {
			  intList1.add(i, x[i]);
		  }
			 
		//lst.remove(1);
		  intList1.remove(1);
		System.out.println("finished");
	}
}
