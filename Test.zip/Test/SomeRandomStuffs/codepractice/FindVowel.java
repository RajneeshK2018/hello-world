package codepractice;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FindVowel {
    public static void main(String[] arg){
/*    String s = "pune";
    System.out.println("find vowel regexp:"+findVowelRegexp(s));*/
        String mydata = "some string with 'the data i want' inside";
        Pattern pattern = Pattern.compile(".*[aeiou].*");
        Matcher matcher = pattern.matcher(mydata);
        if (matcher.find())
        {
            System.out.println(matcher.group(0));
        }

    }

    private static String findVowelRegexp(String s) {
        String regEx = ".*[aeiou].*";
        Pattern pattern = Pattern.compile(regEx);
        Matcher matcher = pattern.matcher(s);

        //boolean match = matcher.matches();

        final List<String> matches = new ArrayList<>();
        while (matcher.find()) {
            System.out.println(matcher.group());
            System.out.println("Pattern found from " + matcher.start() +
                    " to " + (matcher.end()-1));
            //matches.add(matcher.group(0));
        }

        System.out.println(matcher);
        //System.out.println(match);
        return "";
    }
}
