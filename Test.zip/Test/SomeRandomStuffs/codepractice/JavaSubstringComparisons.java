package codepractice;

import java.util.TreeSet;

public class JavaSubstringComparisons {

    public static void main(String args[]){
        String s = "aAbcdefghaa";
        int x =2;

        printLexicallySmallestAndBiggest(s,x);
    }

    private static void printLexicallySmallestAndBiggest(String s, int x) {
        int noCOunter = 0;

        if (s.length()%x == 0){
            noCOunter = s.length()/x;
        }else{
            noCOunter = s.length()/x +1;
        }
        noCOunter = s.length() - x+1;

        TreeSet<String> ts = new TreeSet<>();

        for (int i=0; i<=noCOunter-1;i++ ){
            String sub = "";
            sub = s.substring(i,i+x);
            ts.add(sub);
            //System.out.println(sub);
        }

        System.out.println(ts.first());
        System.out.println(ts.last());
    }

}
