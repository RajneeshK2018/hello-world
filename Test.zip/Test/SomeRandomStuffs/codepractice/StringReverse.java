package codepractice;
//https://www.journaldev.com/370/java-programming-interview-questions
import java.util.Arrays;

public class StringReverse {
    public static  void main(String[] s){
        String str = "pune is cool";
        System.out.println(reverseStringBUilder(str));
        System.out.println(reverseCharArray(str));
    }

    private static String reverseCharArray(String str) {
        char[] ch = str.toCharArray();
        StringBuilder sb = new StringBuilder();
        int arrLen = ch.length;
        for(int i = arrLen -1; i >=0 ; i--){
            sb.append(ch[i]);
        }
        return sb.toString();
    }

    private static String reverseStringBUilder(String s) {
        StringBuilder sb = new StringBuilder(s);
        return sb.reverse().toString();
    }
}
