package codepractice;

import java.util.Collections;

public class Diamond {
    public static  void main(String[] args){
        System.out.println("");
        int x = 5;
        for(int i=1; i<=x; i++){
            printPattern(i);
        }
    }

    public static void printPattern(int n){

        StringBuffer sb = new StringBuffer();
        for (int i=1; i <= n; i++){
            sb.append("* ");
        }
        System.out.println(sb);
    }
}
