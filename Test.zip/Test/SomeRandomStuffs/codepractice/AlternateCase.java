package codepractice;

public class AlternateCase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "abcde";
		StringBuffer sb = new StringBuffer();
		for (int i=0; i< s.length();i++) {
			if (i%2 == 0) {
				String tempS = "";
				tempS = s.substring(i, i+1);
				sb.append(tempS.toUpperCase());
			}else {
				String tempS = "";
				tempS = s.substring(i, i+1);
				sb.append(tempS);
			}
		}
		System.out.println(sb);

	}

}
