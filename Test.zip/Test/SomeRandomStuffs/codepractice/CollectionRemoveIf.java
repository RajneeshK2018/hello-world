package codepractice;

import java.util.*;
import java.util.ArrayList;

public class CollectionRemoveIf {
    public static  void main(String[] args){
        System.out.println("");

        ArrayList<String> obj = new ArrayList<String>(
                Arrays.asList("aa","dd","rr","bb"));

        obj.removeIf(i -> i.matches("^a.*"));

        obj.sort(new Comparator<String>() {
            @Override
            public int compare(String o1, String o2) {
                return o1.compareTo(o2);
            }
        });

        System.out.println("");
    }
}
