package codepractice;

public class ReverseStringPreserveWhiteSpace {
    public static  void main(String[] args){
        String s = "I am in pune";
        System.out.println(s);
        StringBuilder sb = new StringBuilder(s);
        sb.reverse();
        String s1 = sb.toString().replace(" ","");
        System.out.println(sb);
        System.out.println(s1);
    }
}
