package codepractice;

public class UniqueCharsInString {
    public static  void main(String[] args){
        String s = "abcd";
        boolean f = false;
        String newS = "";
        for(int i=0; i<s.length(); i++){
            newS = s.replace(""+s.charAt(i),"");
            if (s.length() - newS.length() > 1 ){
                System.out.println("Not unique");
                f = true;
                break;
            }
        }
        if (!f){
            System.out.println("unique");
        }
    }
}
