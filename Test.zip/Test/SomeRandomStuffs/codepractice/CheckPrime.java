package codepractice;

public class CheckPrime {

    public static  void main(String[] args){
        int n = 13;
        System.out.println(checkPrime(n));
    }

    private static boolean checkPrime(int n) {
        for(int i = 2; i < n -1; i++){
            if(n%i == 0){
                return true;
            }
        }
        return false;
    }
}
