package codepractice;

public class armstrongNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x = 12;
		Integer xx = new Integer(x);
		
		
	}

}
