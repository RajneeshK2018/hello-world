package codepractice;

public class OdEven {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x = 0;
		x = 801;
		
		if(x%2 == 0) {
		System.out.println("even");	
		}else {
			System.out.println("odd");	
		}
		
	}
}
