package codepractice;

public class Palindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "madam";
		palindrome(s);
	}
	
	public static void palindrome(String s) {
		StringBuffer sb = new StringBuffer(s);
		String s2 = sb.reverse().toString();
		
		if (s.equals(s2)) {
			System.out.println("Pelindrome");
		}else {
			System.out.println("Not a Pelindrome");
		}
		
	}

}
