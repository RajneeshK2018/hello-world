package codepractice;

public class ReplaceAllwhitespace {
    public static  void main(String[] args){
        String s = "a, s, d,   ,f g";
        System.out.println(s.replaceAll(",\\s+",""));
    }
}
