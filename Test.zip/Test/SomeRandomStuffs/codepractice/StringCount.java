package codepractice;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StringCount {
    public static  void main(String[] args){
        String in = "i have a male cat. the color of male cat is Black";
        int i = 0;
        Pattern p = Pattern.compile("Male caT", Pattern.CASE_INSENSITIVE | Pattern.LITERAL);
        Matcher m = p.matcher( in );
        while (m.find()) {
            i++;
        }
        System.out.println(i); // Prints 2
    }
}