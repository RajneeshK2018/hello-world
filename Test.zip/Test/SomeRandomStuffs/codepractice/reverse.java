package codepractice;

public class reverse {
	public static void main(String[] args) {
		String s = "2589";
		ReverseIt(s);
		ReverseItJ8(s);

	}
	
	public static void ReverseIt(String s) {
		int lenS = s.length();
		StringBuilder sb = new StringBuilder().reverse();
		while(lenS > 0) {
			sb = sb.append(s.charAt(lenS-1));
			lenS--;
		}
		System.out.println("ReverseIt"+sb);
	}
	
	public static void ReverseItJ8(String s) {

		StringBuilder rev = new StringBuilder(s).reverse();
		StringBuilder del = new StringBuilder(s).deleteCharAt(6);
		System.out.println(rev);
		System.out.println(del);
	}
}
