package codepractice;

import java.util.Arrays;

public class LargestNumberArray {
    public static  void main(String[] args){
        int indexLargestNumber = 3;
        int[] arr2 = new int[]{1,2,3,4,50,20};
        Arrays.sort(arr2);
        System.out.println(""+arr2[arr2.length - indexLargestNumber]);
    }
}
