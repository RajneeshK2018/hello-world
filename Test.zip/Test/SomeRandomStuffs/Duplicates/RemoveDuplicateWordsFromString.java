package Duplicates;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

public class RemoveDuplicateWordsFromString {
    public static  void main(String[] args){
        String s = "hello world hello hello world i am am in in p p pune";
        Set<String> removeDup = new LinkedHashSet<>();
        String[] arrS = s.split(" ");
        for (int i = 0; i < arrS.length; i++){
            removeDup.add(arrS[i]);
        }
        System.out.println(removeDup);
    }
}
