package Duplicates;

import java.util.LinkedHashSet;
import java.util.Set;

public class RemoveDuplicateFromIntArray {
    public static  void main(String[] args){
        int[] arrInt = {1,1,2,3,4,4,5,6};
        LinkedHashSet<Integer> removeDup = new LinkedHashSet<>();

        for (int i = 0; i < arrInt.length; i++){
            removeDup.add(arrInt[i]);
        }
        System.out.println(removeDup);
    }
}
