package Top50Questions;

import java.util.ArrayList;
import java.util.Arrays;

public class MinimumValueFromArray {
    public static void main(String[] args){
        System.out.println("no args");
        int[] x = {1,2,3,4,-3,-90,5};
        System.out.println(getMinArray(x));
    }

    private static int getMinArray(int[] x) {
        Arrays.sort(x);
        return  x[0];
    }

//    public static void main(){
//        System.out.println("args");
//    }
}
