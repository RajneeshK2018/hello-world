package Top50Questions;

public class LongestPelindrome {
    String s = "abbaba";
    public static  void main(String[] args){
        System.out.println("");
    }

    public  void permutations(String s){
        String s1 = "";
        String s2 = "";
    }

    public String swap(String s1, String s2){
        return s2+s1;
    }
}
