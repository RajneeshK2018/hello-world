package Top50Questions;

import java.util.LinkedHashSet;
import java.util.Set;

public class RemoveDuplicates {
    public static  void main(String[] args){
        int[] arr = {1,2,3,2, 1, 2,3,1};
        System.out.println("");
        ;
        System.out.println(removeDuplicate(arr));
    }

    private static int[] removeDuplicate(int[] arr) {
        Set<Integer> set = new LinkedHashSet<>();
        for (int i=0; i< arr.length; i++){
            set.add(arr[i]);
        }

        int[] noDuplicatesArr = new int[set.size()];
        int i=0;
        for (int s : set) {
            noDuplicatesArr[i] = s;
            i++;
        }

        return noDuplicatesArr;
    }

}
