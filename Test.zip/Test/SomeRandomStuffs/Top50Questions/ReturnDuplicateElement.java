package Top50Questions;

import java.util.Arrays;

public class ReturnDuplicateElement {
    public static void main(String[] args) {
        int[] arr = {4,2,3,4,5,1};

        System.out.println(returnDuplicateElement(arr));
    }

    private static int returnDuplicateElement(int[] arr) {
        Arrays.sort(arr);
        int duplicate =0;
        for(int i=0; i<arr.length; i++){
            if(arr[i] == arr[i+1]){
                //System.out.println(arr[i]);
                duplicate = arr[i];
                break;
            }
        }
        return duplicate;
    }
}
