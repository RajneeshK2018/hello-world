package Top50Questions;

public class FirstFirstRepeatingCharacter {
    public static  void main(String[] args){
        String s = "Punpen";
        getFirstRepetingChar(s);
        getFirstRepetingChar2(s);
    }

    private static void getFirstRepetingChar2(String s) {
        char[] arrChr = s.toCharArray();

        for(int i=0; i< arrChr.length -1 ; i++){
            if(arrChr[i] == arrChr[i+1]){
                System.out.println("getFirstRepetingChar2"+arrChr[i] );
                break;
            }
        }
    }

    public static void getFirstRepetingChar(String s){

        for(int i=0; i < s.length()-1; i++){
            String s1 = s.substring(i,i+1);
            String newS = s.replace(s1, "");
            if((s.length() - newS.length()) > 1){
                System.out.println(s1);
                break;
            }
        }
    }
}
