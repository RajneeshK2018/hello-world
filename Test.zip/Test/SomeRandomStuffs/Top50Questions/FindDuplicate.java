package Top50Questions;

import java.lang.reflect.Array;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class FindDuplicate {
    private  static HashMap<Integer, Integer> hm = new HashMap<>();
    public static  void main(String[] args){
        System.out.println("");
        Integer[] arr = {1,2,3,4,1,3,1};
        findDuplicate(arr);
        
        getElementsWhichAreRepeated();
        getElementWithMaxRepeat();
    }

    private static int getElementWithMaxRepeat() {
       int repeat = 0;
       int k = 0;
       for(int key : hm.keySet()){
           if(hm.get(key) > repeat){
               repeat = hm.get(key);
               k = key;
           }
       }
       return k;
    }

    private static void getElementsWhichAreRepeated() {
        for (int key : hm.keySet()) {
            if(hm.get(key) > 1){
                System.out.println(hm.get(key));
            }
        }
    }

    private static void findDuplicate(Integer[] arr) {

        //String s = Stream.of(arr).map(String::valueOf).collect(Collectors.joining("-"));
        List<Integer> al = Arrays.asList(arr);

        for(int x:al){
            int i = 0;
            if(hm.containsKey(x)){
                hm.put(x,hm.get(x)+1);
            }else{
                hm.put(x,++i);
            }
        }
    }
}
