package Top50Questions;

public class ArrayMultiplication {
    public static void main(String[] args) {
        int[] arr = {4, 2, 3, 4, 5, 1};

        System.out.println(arrayMultiplication(arr));
    }

    private static boolean arrayMultiplication(int[] arr) {
        int[] mulArray = new int[arr.length];

        for(int i=0; i < arr.length;i++ ){
            int temp = 0;
//            for (int j=0; j < )
        }
        return true;
    }


}