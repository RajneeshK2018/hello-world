package Top50Questions;

import java.util.ArrayList;

public class LongestSubString {
    public static  void main(String[] args){
        String s = "abcamnop";
        System.out.println("");
        int end = 0;
        int start =0;

        ArrayList<String> al = new ArrayList<>();
        char[] chrArrs = s.toCharArray();
        String sub = "";
        for(int i=0; i< chrArrs.length; i++ ){
            if(sub.contains(chrArrs[i]+"")){
                al.add(sub);
                sub="";
            }else{
                sub = sub + Character.toString(chrArrs[i]);
            }
        }

    }
}
