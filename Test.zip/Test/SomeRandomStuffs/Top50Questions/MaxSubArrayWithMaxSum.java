package Top50Questions;

import java.util.Arrays;

public class MaxSubArrayWithMaxSum {
    public static  void main(String[] args){
        //int[] arr = {1,2,3,4,-10,6,5};
        int[] arr = {1,-10,6,5};
        System.out.println("");
        getMaxSubString(arr);
    }

    private static void getMaxSubString(int[] arr) {
        int mxSum = 0;
        int mxStart=0;
        int mxEnd=0;

        for(int i=0; i <= arr.length;i++){
            for(int j=i+1; j<=arr.length; j++){
                int[] subArr;
                subArr = Arrays.copyOfRange(arr, i, j);
                int tempSum = getSumOfAllArrayElements(subArr);
                if(tempSum > mxSum){
                    mxSum = tempSum;
                    mxStart = i;
                    mxEnd = j;
                }
            }
            System.out.println(mxSum+","+mxStart+","+mxEnd);
        }
    }

    private static int getSumOfAllArrayElements(int[] subArr) {
        int sum = 0;
        for (int i=0; i < subArr.length; i++){
            sum += subArr[i];
        }
        return sum;
    }
}
