package Top50Questions;

public class PeakElelment {
    public static  void main(String[] args){
        System.out.println("");
        int[] arr = {1,5,2,6,6,3};

        for (int i=1; i<=arr.length-1;i++){
            //first element is peak
            if(i==1 && (arr[i-1] > arr[i])){
                System.out.println(arr[i]);
            }
            //last element is peak
            if((arr[i-1] <= arr[i]) && (arr[i] >= arr[i+1])){
                System.out.println(i+","+arr[i]);
            }
            //middle ele is peak
            if(i==arr.length -1 && (arr[i-1] < arr[i])){
                System.out.println(arr[i]);
            }
        }
    }
}
