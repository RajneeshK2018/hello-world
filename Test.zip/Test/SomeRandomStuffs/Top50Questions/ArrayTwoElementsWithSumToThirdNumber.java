package Top50Questions;

import java.util.Arrays;
import java.util.HashMap;

public class ArrayTwoElementsWithSumToThirdNumber {
    public static  void main(String[] args){
        System.out.println("");
        int[] x = {1,2,3,4,5,9,10,-1};
        HashMap<Integer, String> hm =new HashMap<>();
        for(int i=0; i < x.length; i++){
            int tempInt = x[i];
            for (int j=0; j< x.length;j++){
                if(i != j){
                    int temp2= x[j];
                    int a = Arrays.binarySearch(x, tempInt - temp2);
                    if(a > 0 && (a != j)) {
                        if(!hm.containsKey(tempInt)){
                                hm.put(tempInt, a+","+j );
                                System.out.println(tempInt + "," + temp2 + "," + x[a]);
                        }else{
                            if(!hm.get(tempInt).contains(""+j)){
                                hm.put(tempInt, a+","+j );
                                System.out.println(tempInt + "," + temp2 + "," + x[a]);
                            }
                        }
                    }
                }
            }
        }
    }
}
