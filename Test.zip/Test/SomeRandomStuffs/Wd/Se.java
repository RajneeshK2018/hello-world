package Wd;

import org.apache.http.util.Asserts;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;

import javax.swing.*;
import java.util.concurrent.TimeUnit;

public class Se {


    public static void main(String args[]){
        System.setProperty("webdriver.chrome.driver", "./Lib/chromedriver.exe");
        ChromeDriver driver = new ChromeDriver();
        driver.get("https://amazon.in");
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        //WebElement ele = driver.findElement(By.xpath("XPath of element"));

        //driver.getScreenshotAs()

        //driver.close();

    }
}
