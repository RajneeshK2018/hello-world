package Wd.streams;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class uniqueElemsList {
    public static  void main(String[] args){
        System.out.println("");
        List<String> listAll = Arrays.asList("CO2", "CH4", "SO2", "CO2", "CH4", "SO2", "CO2", "CH4", "SO2");

// Create a list with the distinct elements using stream.
        List<String> listDistinct = listAll.stream().distinct().collect(Collectors.toList());
        // Display them to terminal using stream::collect with a build in Collector.
        String collectAll = listAll.stream().collect(Collectors.joining(", "));
        System.out.println(collectAll); //=> CO2, CH4, SO2, CO2, CH4 etc..
        String collectDistinct = listDistinct.stream().collect(Collectors.joining(", "));
        System.out.println(collectDistinct); //=> CO2, CH4, SO2
    }
}
