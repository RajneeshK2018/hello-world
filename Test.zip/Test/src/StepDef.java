public class StepDef {

    @before
    public void setup(){
    }

    @beforeEach
    public void prerequisire(){
    }

    @afterEach
    public void afterEachScenario(){
    }

    @after
    public void teardown(){
    }


    @Given "i navigate to $url"
    public void navigateUrl(String url){

    }
}
